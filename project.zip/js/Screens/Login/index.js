import component from './Login'
export default component