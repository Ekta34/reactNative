import Authorization from './Authorization'
import Login from './Login'
import FirstTab from './FirstTab'
import SecondTab from './SecondTab'
exports.Authorization = Authorization
exports.Login = Login
exports.FirstTab = FirstTab
exports.SecondTab = SecondTab