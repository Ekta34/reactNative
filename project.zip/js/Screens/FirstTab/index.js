import component from './FirstTab'
export default component