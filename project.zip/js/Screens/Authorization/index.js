import component from './Authorization'
export default component