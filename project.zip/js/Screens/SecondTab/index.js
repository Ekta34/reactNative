import component from './SecondTab'
export default component