import Root from './RootNavigator'
import Main from './MainNavigator'
exports.Root = Root
exports.Main = Main